please go to Appearence => WpOpal Import 

then click to download remoted package which will use for onclick function to make sample like as demo

or you copy sample data from downloadable package put here then use the import tools