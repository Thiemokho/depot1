<?php 
if ( ! is_active_sidebar( 'mass-footer-body' ) ) {
	return;
}
?> 
<?php dynamic_sidebar( 'mass-footer-body' ); ?>
 