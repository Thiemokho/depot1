<section id="pbr-topbar" class="pbr-topbar pbr-topbar-v8">
	<div class="container clearfix">

        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-9">
                <div class="left-top-bar">
                    <?php dynamic_sidebar( 'left-top-bar' ); ?>
                </div>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3 clearfix">
                <div class="user-login pull-right">

                    <?php get_template_part( 'page-templates/parts/user-login' ); ?>

                </div>
            </div>
            
        </div>
        <!-- .row -->
            

	</div>	
</section>